package com.dodo.yash808;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private WebView webview1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	
	private void initializeLogic() {
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setDomStorageEnabled(true);
		webview1.getSettings().setAllowFileAccess(true);
		webview1.getSettings().setAllowContentAccess(true);
		
		webview1.loadUrl("file:///android_asset/index.html");
		
		webview1.setWebViewClient(new android.webkit.WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(android.webkit.WebView view, String url) {
				if (url.startsWith("mailto:")) {
					try {
						android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_SENDTO);
						intent.setData(android.net.Uri.parse(url));
						startActivity(intent);
					} catch (Exception e) {
						try {
							android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_SEND);
							intent.setType("message/rfc822");
							intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"yashansh@proton.me"});
							intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Productivity Hub - Feedback");
							startActivity(android.content.Intent.createChooser(intent, "Send Email"));
						} catch (Exception ex) {
							android.widget.Toast.makeText(getApplicationContext(), "No email app found", android.widget.Toast.LENGTH_SHORT).show();
						}
					}
					return true;
				}
				return false;
			}
		});
		
		webview1.addJavascriptInterface(new Object() {
			
			@android.webkit.JavascriptInterface
			public void saveData(String key, String value) {
				getSharedPreferences("todo_data", MODE_PRIVATE)
				.edit()
				.putString(key, value)
				.apply();
			}
			
			@android.webkit.JavascriptInterface
			public String loadData(String key) {
				return getSharedPreferences("todo_data", MODE_PRIVATE)
				.getString(key, "");
			}
			
			@android.webkit.JavascriptInterface
			public void openEmail(String email, String subject, String body) {
				try {
					android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_SENDTO);
					intent.setData(android.net.Uri.parse("mailto:" + email));
					intent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);
					intent.putExtra(android.content.Intent.EXTRA_TEXT, body);
					startActivity(intent);
				} catch (Exception e) {
					try {
						android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_SEND);
						intent.setType("message/rfc822");
						intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{email});
						intent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);
						intent.putExtra(android.content.Intent.EXTRA_TEXT, body);
						startActivity(android.content.Intent.createChooser(intent, "Send Email"));
					} catch (Exception ex) {
						android.widget.Toast.makeText(getApplicationContext(), "No email app found", android.widget.Toast.LENGTH_SHORT).show();
					}
				}
			}
			
		}, "Android");
		getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
		
		try {
			android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
			java.util.List<android.app.ActivityManager.AppTask> tasks = am.getAppTasks();
			if (tasks != null && !tasks.isEmpty()) {
				tasks.get(0).setExcludeFromRecents(true);
			}
		} catch (Exception e) {}
	}
	
}